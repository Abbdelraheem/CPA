import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Play } from "lucide-react";
import type { Ad } from "@shared/schema";

export default function AdsSection() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: ads, isLoading } = useQuery<Ad[]>({
    queryKey: ["/api/ads"],
  });

  const watchAdMutation = useMutation({
    mutationFn: async (adId: number) => {
      await apiRequest("POST", `/api/ads/${adId}/watch`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Ad completed! Earnings have been added to your balance.",
      });
      // Invalidate related queries to refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to complete ad. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleWatchAd = () => {
    if (ads && ads.length > 0) {
      // In a real implementation, you would show the ad video first
      // For now, we'll simulate watching the first available ad
      watchAdMutation.mutate(ads[0].id);
    }
  };

  const availableAdsCount = ads?.length || 0;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Watch Ads & Earn</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="bg-gray-100 rounded-lg p-8 text-center">
          <Play className="mx-auto text-6xl text-primary mb-4" />
          <h4 className="text-lg font-medium text-gray-900 mb-2">Ready to Watch Ads?</h4>
          <p className="text-gray-600 mb-4">Earn $0.50 - $2.00 per ad watched</p>
          <div className="flex items-center justify-center space-x-4">
            <Button
              onClick={handleWatchAd}
              disabled={watchAdMutation.isPending || availableAdsCount === 0}
              className="bg-success hover:bg-success/90"
            >
              <Play className="mr-2 h-4 w-4" />
              {watchAdMutation.isPending
                ? "Processing..."
                : availableAdsCount > 0
                ? `Start Watching (${availableAdsCount} ads available)`
                : "No ads available"}
            </Button>
          </div>
          {availableAdsCount === 0 && (
            <p className="text-sm text-gray-500 mt-2">
              Check back later for more ads to watch
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
