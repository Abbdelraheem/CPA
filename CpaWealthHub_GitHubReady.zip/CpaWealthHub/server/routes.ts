import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertPaymentSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Generate referral code if user doesn't have one
      if (!user.referralCode) {
        const referralCode = await storage.generateReferralCode();
        await storage.upsertUser({
          ...user,
          referralCode,
        });
        user.referralCode = referralCode;
      }

      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Dashboard stats
  app.get('/api/dashboard/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getUserStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Get offers
  app.get('/api/offers', isAuthenticated, async (req, res) => {
    try {
      const offers = await storage.getOffers();
      res.json(offers);
    } catch (error) {
      console.error("Error fetching offers:", error);
      res.status(500).json({ message: "Failed to fetch offers" });
    }
  });

  // Start offer
  app.post('/api/offers/:id/start', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const offerId = parseInt(req.params.id);
      
      const userOffer = await storage.startOffer(userId, offerId);
      res.json(userOffer);
    } catch (error) {
      console.error("Error starting offer:", error);
      res.status(500).json({ message: "Failed to start offer" });
    }
  });

  // Complete offer
  app.post('/api/offers/:id/complete', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const offerId = parseInt(req.params.id);
      
      const userOffer = await storage.completeOffer(userId, offerId);
      if (!userOffer) {
        return res.status(404).json({ message: "Offer not found or already completed" });
      }
      
      res.json(userOffer);
    } catch (error) {
      console.error("Error completing offer:", error);
      res.status(500).json({ message: "Failed to complete offer" });
    }
  });

  // Get ads
  app.get('/api/ads', isAuthenticated, async (req, res) => {
    try {
      const ads = await storage.getAds();
      res.json(ads);
    } catch (error) {
      console.error("Error fetching ads:", error);
      res.status(500).json({ message: "Failed to fetch ads" });
    }
  });

  // Watch ad
  app.post('/api/ads/:id/watch', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const adId = parseInt(req.params.id);
      
      const adView = await storage.watchAd(userId, adId);
      res.json(adView);
    } catch (error) {
      console.error("Error watching ad:", error);
      res.status(500).json({ message: "Failed to watch ad" });
    }
  });

  // Get user activities
  app.get('/api/activities', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = parseInt(req.query.limit as string) || 10;
      
      const activities = await storage.getUserActivities(userId, limit);
      res.json(activities);
    } catch (error) {
      console.error("Error fetching activities:", error);
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });

  // Get referral stats
  app.get('/api/referrals/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getReferralStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching referral stats:", error);
      res.status(500).json({ message: "Failed to fetch referral stats" });
    }
  });

  // Request payment
  app.post('/api/payments/request', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      const validatedData = insertPaymentSchema.parse({
        ...req.body,
        userId,
      });
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const minPayoutAmount = 50; // $50 minimum
      if (parseFloat(user.balance) < minPayoutAmount) {
        return res.status(400).json({ 
          message: `Minimum payout amount is $${minPayoutAmount}. Your current balance is $${user.balance}` 
        });
      }

      const payment = await storage.createPaymentRequest({
        ...validatedData,
        amount: user.balance,
      });

      // Create activity
      await storage.createActivity({
        userId,
        type: "payment_requested",
        description: `Payment request for $${user.balance} via ${validatedData.method}`,
        amount: "0.00",
      });

      res.json(payment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid payment data", errors: error.errors });
      }
      console.error("Error requesting payment:", error);
      res.status(500).json({ message: "Failed to request payment" });
    }
  });

  // Get user payments
  app.get('/api/payments', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const payments = await storage.getUserPayments(userId);
      res.json(payments);
    } catch (error) {
      console.error("Error fetching payments:", error);
      res.status(500).json({ message: "Failed to fetch payments" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
