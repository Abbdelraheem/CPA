import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Header from "@/components/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Copy, Users, DollarSign, TrendingUp, Share2, Gift } from "lucide-react";

export default function Referrals() {
  const { isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: referralStats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/referrals/stats"],
    enabled: isAuthenticated,
  });

  const { data: referralEarnings, isLoading: earningsLoading } = useQuery({
    queryKey: ["/api/referrals/earnings"],
    enabled: isAuthenticated,
  });

  const copyReferralLink = () => {
    if (referralStats?.referralLink) {
      navigator.clipboard.writeText(referralStats.referralLink);
      toast({
        title: "Copied!",
        description: "Referral link copied to clipboard",
      });
    }
  };

  const shareOnSocial = (platform: string) => {
    const link = referralStats?.referralLink;
    const text = "Join me on ProfitHub and start earning money with CPA offers and ads!";
    
    let shareUrl = "";
    switch (platform) {
      case "facebook":
        shareUrl = `https://facebook.com/sharer/sharer.php?u=${encodeURIComponent(link)}`;
        break;
      case "twitter":
        shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(link)}`;
        break;
      case "linkedin":
        shareUrl = `https://linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(link)}`;
        break;
      case "whatsapp":
        shareUrl = `https://wa.me/?text=${encodeURIComponent(text + " " + link)}`;
        break;
    }
    
    if (shareUrl) {
      window.open(shareUrl, "_blank", "width=600,height=400");
    }
  };

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="max-w-7xl mx-auto p-8">
          <Skeleton className="h-8 w-48 mb-8" />
          <div className="grid gap-6">
            {[...Array(4)].map((_, i) => (
              <Skeleton key={i} className="h-48" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Referral Program</h1>
          <p className="text-gray-600">Earn 20% commission on your referrals' earnings for life</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center">
                <Users className="h-8 w-8 text-primary mr-3" />
                <div>
                  <p className="text-sm text-gray-600">Total Referrals</p>
                  <p className="text-3xl font-bold">
                    {statsLoading ? "..." : referralStats?.count || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center">
                <DollarSign className="h-8 w-8 text-success mr-3" />
                <div>
                  <p className="text-sm text-gray-600">Total Earnings</p>
                  <p className="text-3xl font-bold text-success">
                    ${statsLoading ? "..." : referralStats?.totalEarnings || "0.00"}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center">
                <TrendingUp className="h-8 w-8 text-warning mr-3" />
                <div>
                  <p className="text-sm text-gray-600">Commission Rate</p>
                  <p className="text-3xl font-bold text-warning">20%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Referral Link Section */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Share2 className="mr-2 h-5 w-5" />
                  Your Referral Link
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-success-light rounded-lg p-4">
                  <h4 className="font-medium text-success mb-2">Earn 20% Commission</h4>
                  <p className="text-sm text-gray-600">
                    Get 20% of your referrals' earnings for life. The more they earn, the more you earn!
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Share this link with friends and family
                  </label>
                  <div className="flex space-x-2">
                    <Input 
                      value={referralStats?.referralLink || ""}
                      readOnly
                      className="flex-1"
                    />
                    <Button 
                      onClick={copyReferralLink}
                      variant="outline"
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div>
                  <p className="text-sm font-medium text-gray-700 mb-3">Share on social media</p>
                  <div className="flex space-x-2">
                    <Button 
                      size="sm"
                      variant="outline"
                      className="bg-blue-600 text-white hover:bg-blue-700"
                      onClick={() => shareOnSocial("facebook")}
                    >
                      Facebook
                    </Button>
                    <Button 
                      size="sm"
                      variant="outline"
                      className="bg-sky-500 text-white hover:bg-sky-600"
                      onClick={() => shareOnSocial("twitter")}
                    >
                      Twitter
                    </Button>
                    <Button 
                      size="sm"
                      variant="outline"
                      className="bg-blue-700 text-white hover:bg-blue-800"
                      onClick={() => shareOnSocial("linkedin")}
                    >
                      LinkedIn
                    </Button>
                    <Button 
                      size="sm"
                      variant="outline"
                      className="bg-green-500 text-white hover:bg-green-600"
                      onClick={() => shareOnSocial("whatsapp")}
                    >
                      WhatsApp
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* How It Works */}
            <Card>
              <CardHeader>
                <CardTitle>How It Works</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="bg-primary text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">
                      1
                    </div>
                    <div>
                      <h4 className="font-medium">Share Your Link</h4>
                      <p className="text-sm text-gray-600">
                        Share your unique referral link with friends and family
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <div className="bg-primary text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">
                      2
                    </div>
                    <div>
                      <h4 className="font-medium">They Sign Up</h4>
                      <p className="text-sm text-gray-600">
                        When someone clicks your link and creates an account, they become your referral
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <div className="bg-success text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">
                      3
                    </div>
                    <div>
                      <h4 className="font-medium">You Earn Commission</h4>
                      <p className="text-sm text-gray-600">
                        Earn 20% of everything they earn from offers and ads, forever!
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Bonus Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Gift className="mr-2 h-5 w-5 text-warning" />
                  Referral Bonuses
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center p-3 bg-yellow-50 rounded-lg">
                    <div>
                      <h4 className="font-medium">5 Referrals</h4>
                      <p className="text-sm text-gray-600">Bonus: $10</p>
                    </div>
                    <Badge variant={referralStats?.count >= 5 ? "default" : "secondary"}>
                      {referralStats?.count >= 5 ? "Earned" : "Pending"}
                    </Badge>
                  </div>

                  <div className="flex justify-between items-center p-3 bg-yellow-50 rounded-lg">
                    <div>
                      <h4 className="font-medium">25 Referrals</h4>
                      <p className="text-sm text-gray-600">Bonus: $50</p>
                    </div>
                    <Badge variant={referralStats?.count >= 25 ? "default" : "secondary"}>
                      {referralStats?.count >= 25 ? "Earned" : "Pending"}
                    </Badge>
                  </div>

                  <div className="flex justify-between items-center p-3 bg-yellow-50 rounded-lg">
                    <div>
                      <h4 className="font-medium">100 Referrals</h4>
                      <p className="text-sm text-gray-600">Bonus: $200</p>
                    </div>
                    <Badge variant={referralStats?.count >= 100 ? "default" : "secondary"}>
                      {referralStats?.count >= 100 ? "Earned" : "Pending"}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Referral Earnings History */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Referral Earnings History</CardTitle>
              </CardHeader>
              <CardContent>
                {earningsLoading ? (
                  <div className="space-y-3">
                    {[...Array(8)].map((_, i) => (
                      <Skeleton key={i} className="h-16" />
                    ))}
                  </div>
                ) : referralEarnings?.length === 0 ? (
                  <div className="text-center py-12">
                    <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                      No referral earnings yet
                    </h3>
                    <p className="text-gray-600">
                      Start sharing your referral link to earn commissions
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {referralEarnings?.map((earning: any) => (
                      <div 
                        key={earning.id}
                        className="flex items-center justify-between p-3 border rounded-lg"
                      >
                        <div>
                          <h4 className="font-medium">Commission Earned</h4>
                          <p className="text-sm text-gray-600">
                            From {earning.sourceType === "offer" ? "offer completion" : "ad view"}
                          </p>
                          <p className="text-xs text-gray-500">
                            {new Date(earning.earnedAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-bold text-success">
                            +${earning.amount}
                          </div>
                          <Badge variant="outline" className="text-xs">
                            20% Commission
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
