import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Coins, DollarSign, Users, Shield, Lock, Globe, TrendingUp } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Coins className="text-success text-2xl mr-3" />
              <h1 className="text-2xl font-bold text-gray-900">ProfitHub</h1>
            </div>
            <Button onClick={handleLogin} className="bg-primary hover:bg-primary/90">
              Get Started
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Earn Money Online with <span className="text-primary">CPA Offers</span> & <span className="text-success">Video Ads</span>
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Join over 50,000 users worldwide earning real money through high-paying CPA offers, 
            video advertisements, and our lucrative referral program. Get started today and turn your time into profit.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button onClick={handleLogin} size="lg" className="bg-primary hover:bg-primary/90 text-lg px-8 py-4">
              Start Earning Now
            </Button>
            <Button variant="outline" size="lg" className="text-lg px-8 py-4">
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-2">$2.5M+</div>
              <div className="text-gray-600">Total Paid Out</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-success mb-2">50K+</div>
              <div className="text-gray-600">Active Users</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-purple-600 mb-2">1000+</div>
              <div className="text-gray-600">Available Offers</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-orange-600 mb-2">24/7</div>
              <div className="text-gray-600">Support Available</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Multiple Ways to Earn</h3>
            <p className="text-xl text-gray-600">Choose from various earning methods that fit your schedule and preferences</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardHeader>
                <DollarSign className="mx-auto text-primary text-4xl mb-4" />
                <CardTitle>High-Paying CPA Offers</CardTitle>
                <CardDescription>Complete simple tasks like signups, surveys, and app downloads to earn $5-$50 per offer</CardDescription>
              </CardHeader>
              <CardContent>
                <Badge className="bg-success-light text-success">Earn $5-$50</Badge>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <TrendingUp className="mx-auto text-success text-4xl mb-4" />
                <CardTitle>Watch Video Ads</CardTitle>
                <CardDescription>Earn money by watching short video advertisements from top brands</CardDescription>
              </CardHeader>
              <CardContent>
                <Badge className="bg-blue-100 text-blue-800">Earn $0.50-$2.00</Badge>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <Users className="mx-auto text-purple-600 text-4xl mb-4" />
                <CardTitle>Referral Program</CardTitle>
                <CardDescription>Earn 20% commission for life from every person you refer to our platform</CardDescription>
              </CardHeader>
              <CardContent>
                <Badge className="bg-purple-100 text-purple-800">20% Commission</Badge>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Trusted & Secure Platform</h3>
            <p className="text-xl text-gray-600">Your security and privacy are our top priorities</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <Shield className="mx-auto text-success text-3xl mb-4" />
              <h4 className="font-semibold text-gray-900 mb-2">SSL Encrypted</h4>
              <p className="text-gray-600 text-sm">All data transmitted securely</p>
            </div>
            
            <div className="text-center">
              <Lock className="mx-auto text-success text-3xl mb-4" />
              <h4 className="font-semibold text-gray-900 mb-2">Secure Payments</h4>
              <p className="text-gray-600 text-sm">Multiple payment methods available</p>
            </div>
            
            <div className="text-center">
              <Globe className="mx-auto text-success text-3xl mb-4" />
              <h4 className="font-semibold text-gray-900 mb-2">Global Network</h4>
              <p className="text-gray-600 text-sm">Connected to major CPA networks</p>
            </div>
            
            <div className="text-center">
              <Users className="mx-auto text-success text-3xl mb-4" />
              <h4 className="font-semibold text-gray-900 mb-2">GDPR Compliant</h4>
              <p className="text-gray-600 text-sm">Privacy rights protected</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h3 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Start Earning?
          </h3>
          <p className="text-xl text-blue-100 mb-8">
            Join thousands of users already earning money with ProfitHub. 
            Sign up today and start your journey to financial freedom.
          </p>
          <Button 
            onClick={handleLogin} 
            size="lg" 
            className="bg-white text-primary hover:bg-gray-100 text-lg px-8 py-4"
          >
            Get Started - It's Free!
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <Coins className="text-success text-xl mr-2" />
                <h3 className="text-lg font-semibold text-gray-900">ProfitHub</h3>
              </div>
              <p className="text-sm text-gray-600">
                The leading platform for earning money through CPA offers and ad viewing. 
                Trusted by over 50,000 users worldwide.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-900 mb-4">Earn Money</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><a href="#" className="hover:text-primary">CPA Offers</a></li>
                <li><a href="#" className="hover:text-primary">Watch Ads</a></li>
                <li><a href="#" className="hover:text-primary">Referral Program</a></li>
                <li><a href="#" className="hover:text-primary">Bonus Campaigns</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-900 mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><a href="#" className="hover:text-primary">Help Center</a></li>
                <li><a href="#" className="hover:text-primary">Payment Issues</a></li>
                <li><a href="#" className="hover:text-primary">Contact Us</a></li>
                <li><a href="#" className="hover:text-primary">FAQ</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-900 mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><a href="#" className="hover:text-primary">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-primary">Terms of Service</a></li>
                <li><a href="#" className="hover:text-primary">GDPR Compliance</a></li>
                <li><a href="#" className="hover:text-primary">Cookie Policy</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-200 mt-8 pt-8 text-center text-sm text-gray-600">
            <p>&copy; 2024 ProfitHub. All rights reserved. | Secure payments processed globally</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
