import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Header from "@/components/header";
import OfferCard from "@/components/offer-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Filter } from "lucide-react";
import { useState } from "react";

export default function Offers() {
  const { isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: offers, isLoading: offersLoading } = useQuery({
    queryKey: ["/api/offers"],
    enabled: isAuthenticated,
  });

  const { data: userOffers } = useQuery({
    queryKey: ["/api/user/offers"],
    enabled: isAuthenticated,
  });

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="max-w-7xl mx-auto p-8">
          <Skeleton className="h-8 w-48 mb-8" />
          <div className="grid gap-6">
            {[...Array(6)].map((_, i) => (
              <Skeleton key={i} className="h-32" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  const filteredOffers = offers?.filter((offer: any) => {
    const matchesSearch = offer.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         offer.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === "all" || offer.category === categoryFilter;
    return matchesSearch && matchesCategory;
  }) || [];

  const getUserOfferStatus = (offerId: number) => {
    const userOffer = userOffers?.find((uo: any) => uo.offerId === offerId);
    return userOffer?.status || null;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">CPA Offers</h1>
          <p className="text-gray-600">Complete high-paying offers and earn money instantly</p>
        </div>

        {/* Filters */}
        <Card className="mb-8">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search offers..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Filter className="h-4 w-4 text-gray-500" />
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="business">Business</SelectItem>
                    <SelectItem value="finance">Finance</SelectItem>
                    <SelectItem value="tech">Technology</SelectItem>
                    <SelectItem value="lifestyle">Lifestyle</SelectItem>
                    <SelectItem value="health">Health</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary mb-1">
                  {offersLoading ? "..." : offers?.length || 0}
                </div>
                <p className="text-sm text-gray-600">Available Offers</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-success mb-1">
                  {offersLoading ? "..." : 
                    userOffers?.filter((uo: any) => uo.status === "completed").length || 0}
                </div>
                <p className="text-sm text-gray-600">Completed</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-warning mb-1">
                  {offersLoading ? "..." : 
                    userOffers?.filter((uo: any) => uo.status === "started").length || 0}
                </div>
                <p className="text-sm text-gray-600">In Progress</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Offers List */}
        <div className="space-y-6">
          {offersLoading ? (
            [...Array(6)].map((_, i) => (
              <Skeleton key={i} className="h-32" />
            ))
          ) : filteredOffers.length === 0 ? (
            <Card>
              <CardContent className="pt-6 text-center">
                <p className="text-gray-500">No offers found matching your criteria.</p>
              </CardContent>
            </Card>
          ) : (
            filteredOffers.map((offer: any) => {
              const status = getUserOfferStatus(offer.id);
              return (
                <div key={offer.id} className="relative">
                  <OfferCard offer={offer} showFullDetails />
                  {status && (
                    <div className="absolute top-4 right-4">
                      <Badge 
                        variant={status === "completed" ? "default" : "secondary"}
                        className={status === "completed" ? "bg-success" : ""}
                      >
                        {status === "completed" ? "Completed" : "In Progress"}
                      </Badge>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
