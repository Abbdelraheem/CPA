import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Header from "@/components/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Play, Pause, SkipForward, Video, Eye, Clock, DollarSign } from "lucide-react";

export default function Ads() {
  const { isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [currentAd, setCurrentAd] = useState<any>(null);
  const [isWatching, setIsWatching] = useState(false);
  const [progress, setProgress] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(0);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: adViews, isLoading: adViewsLoading } = useQuery({
    queryKey: ["/api/user/ad-views"],
    enabled: isAuthenticated,
  });

  const recordAdViewMutation = useMutation({
    mutationFn: async (adData: any) => {
      const response = await apiRequest("POST", "/api/ads/view", adData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Ad Completed!",
        description: `You earned $${currentAd?.payout}`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/user/ad-views"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      setCurrentAd(null);
      setIsWatching(false);
      setProgress(0);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: "Failed to record ad view",
        variant: "destructive",
      });
    },
  });

  // Mock ads data
  const availableAds = [
    {
      id: 1,
      type: "video",
      title: "Business Software Demo",
      duration: 30,
      payout: "1.50",
      thumbnail: "https://images.unsplash.com/photo-1553877522-43269d4ea984?w=300&h=200&fit=crop",
    },
    {
      id: 2,
      type: "video",
      title: "Investment Platform Overview",
      duration: 45,
      payout: "2.00",
      thumbnail: "https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?w=300&h=200&fit=crop",
    },
    {
      id: 3,
      type: "video",
      title: "Tech Product Launch",
      duration: 25,
      payout: "1.25",
      thumbnail: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=300&h=200&fit=crop",
    },
    {
      id: 4,
      type: "banner",
      title: "E-commerce Platform",
      duration: 15,
      payout: "0.75",
      thumbnail: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=300&h=200&fit=crop",
    },
    {
      id: 5,
      type: "video",
      title: "Online Course Preview",
      duration: 60,
      payout: "2.50",
      thumbnail: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=300&h=200&fit=crop",
    },
  ];

  const startWatching = (ad: any) => {
    setCurrentAd(ad);
    setIsWatching(true);
    setProgress(0);
    setTimeRemaining(ad.duration);

    // Simulate ad viewing progress
    const interval = setInterval(() => {
      setProgress((prev) => {
        const newProgress = prev + (100 / ad.duration);
        if (newProgress >= 100) {
          clearInterval(interval);
          completeAd(ad);
          return 100;
        }
        return newProgress;
      });

      setTimeRemaining((prev) => {
        const newTime = prev - 1;
        return newTime <= 0 ? 0 : newTime;
      });
    }, 1000);
  };

  const completeAd = (ad: any) => {
    recordAdViewMutation.mutate({
      adType: ad.type,
      duration: ad.duration,
      payout: ad.payout,
    });
  };

  const pauseAd = () => {
    setIsWatching(false);
    // In a real implementation, you would pause the actual ad
  };

  if (isLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="max-w-7xl mx-auto p-8">
          <Skeleton className="h-8 w-48 mb-8" />
          <div className="grid gap-6">
            {[...Array(4)].map((_, i) => (
              <Skeleton key={i} className="h-48" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Watch Ads & Earn</h1>
          <p className="text-gray-600">Earn money by watching short advertisements</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center">
                <Video className="h-8 w-8 text-primary mr-3" />
                <div>
                  <p className="text-sm text-gray-600">Ads Watched Today</p>
                  <p className="text-2xl font-bold">
                    {adViews?.filter((view: any) => {
                      const today = new Date().toDateString();
                      return new Date(view.viewedAt).toDateString() === today;
                    }).length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center">
                <Eye className="h-8 w-8 text-success mr-3" />
                <div>
                  <p className="text-sm text-gray-600">Total Ads Watched</p>
                  <p className="text-2xl font-bold">{adViews?.length || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center">
                <DollarSign className="h-8 w-8 text-warning mr-3" />
                <div>
                  <p className="text-sm text-gray-600">Earnings from Ads</p>
                  <p className="text-2xl font-bold text-success">
                    ${adViews?.reduce((sum: number, view: any) => sum + parseFloat(view.payout), 0).toFixed(2) || "0.00"}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center">
                <Clock className="h-8 w-8 text-info mr-3" />
                <div>
                  <p className="text-sm text-gray-600">Avg. Daily Earnings</p>
                  <p className="text-2xl font-bold text-success">$4.50</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Ad Player */}
          <div className="lg:col-span-2">
            {currentAd ? (
              <Card className="mb-8">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Currently Watching: {currentAd.title}</span>
                    <Badge className="bg-success">${currentAd.payout}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-black rounded-lg aspect-video mb-4 relative overflow-hidden">
                    <img 
                      src={currentAd.thumbnail}
                      alt={currentAd.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                      <div className="text-white text-center">
                        <div className="text-4xl mb-2">
                          {isWatching ? <Pause /> : <Play />}
                        </div>
                        <p>Ad is playing...</p>
                        <p className="text-sm">Time remaining: {timeRemaining}s</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Progress</span>
                        <span>{Math.round(progress)}%</span>
                      </div>
                      <Progress value={progress} />
                    </div>
                    
                    <div className="flex space-x-2">
                      <Button 
                        onClick={pauseAd}
                        disabled={!isWatching}
                        variant="outline"
                      >
                        <Pause className="mr-2 h-4 w-4" />
                        Pause
                      </Button>
                      <Button 
                        onClick={() => completeAd(currentAd)}
                        disabled={progress < 100 || recordAdViewMutation.isPending}
                        className="bg-success hover:bg-success/90"
                      >
                        <SkipForward className="mr-2 h-4 w-4" />
                        Complete Ad
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="mb-8">
                <CardContent className="pt-6">
                  <div className="text-center py-16">
                    <Video className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                      Select an ad to start earning
                    </h3>
                    <p className="text-gray-600">
                      Choose from the available ads below to start watching and earning money
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Available Ads */}
            <Card>
              <CardHeader>
                <CardTitle>Available Ads ({availableAds.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  {availableAds.map((ad) => (
                    <div 
                      key={ad.id}
                      className="border rounded-lg p-4 hover:shadow-md transition-shadow"
                    >
                      <div className="flex items-center space-x-4">
                        <img 
                          src={ad.thumbnail}
                          alt={ad.title}
                          className="w-20 h-12 rounded object-cover"
                        />
                        <div className="flex-1">
                          <h4 className="font-medium">{ad.title}</h4>
                          <div className="flex items-center space-x-4 text-sm text-gray-600">
                            <span>{ad.duration}s</span>
                            <Badge variant="outline">{ad.type}</Badge>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-bold text-success mb-2">
                            ${ad.payout}
                          </div>
                          <Button 
                            onClick={() => startWatching(ad)}
                            disabled={!!currentAd}
                            size="sm"
                          >
                            <Play className="mr-2 h-4 w-4" />
                            Watch
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar - Recent Ad Views */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Recent Ad Views</CardTitle>
              </CardHeader>
              <CardContent>
                {adViewsLoading ? (
                  <div className="space-y-3">
                    {[...Array(5)].map((_, i) => (
                      <Skeleton key={i} className="h-12" />
                    ))}
                  </div>
                ) : adViews?.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">
                    No ads watched yet
                  </p>
                ) : (
                  <div className="space-y-3">
                    {adViews?.slice(0, 10).map((view: any) => (
                      <div key={view.id} className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium">
                            {view.adType === "video" ? "Video Ad" : "Banner Ad"}
                          </p>
                          <p className="text-xs text-gray-500">
                            {new Date(view.viewedAt).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="text-sm font-medium text-success">
                          +${view.payout}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
