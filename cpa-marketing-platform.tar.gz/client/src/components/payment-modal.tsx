import { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";

export default function PaymentModal() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isOpen, setIsOpen] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState("paypal");
  const [address, setAddress] = useState("");

  // Listen for the custom event to open the modal
  useEffect(() => {
    const handleOpenModal = () => setIsOpen(true);
    window.addEventListener('openPaymentModal', handleOpenModal);
    return () => window.removeEventListener('openPaymentModal', handleOpenModal);
  }, []);

  const paymentMutation = useMutation({
    mutationFn: async (data: { method: string; address: string }) => {
      await apiRequest("POST", "/api/payments/request", data);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Payment request submitted successfully! You will receive your payment within 24-48 hours.",
      });
      setIsOpen(false);
      setAddress("");
      setPaymentMethod("paypal");
      
      // Refresh user data and activities
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/activities"] });
      queryClient.invalidateQueries({ queryKey: ["/api/payments"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to submit payment request. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!address.trim()) {
      toast({
        title: "Error",
        description: "Please enter a valid payment address.",
        variant: "destructive",
      });
      return;
    }

    if (paymentMethod === "paypal" && !address.includes("@")) {
      toast({
        title: "Error",
        description: "Please enter a valid email address for PayPal.",
        variant: "destructive",
      });
      return;
    }

    paymentMutation.mutate({
      method: paymentMethod,
      address: address.trim(),
    });
  };

  const balance = parseFloat(user?.balance || "0");
  const minPayout = 50;

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Request Payment</DialogTitle>
          <DialogDescription>
            Submit a payment request to withdraw your earnings.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="payment-method">Payment Method</Label>
            <Select value={paymentMethod} onValueChange={setPaymentMethod}>
              <SelectTrigger>
                <SelectValue placeholder="Select payment method" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="paypal">PayPal</SelectItem>
                <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                <SelectItem value="crypto">Cryptocurrency</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="amount">Amount</Label>
            <Input
              id="amount"
              value={`$${balance.toFixed(2)}`}
              readOnly
              className="bg-gray-50"
            />
          </div>

          <div>
            <Label htmlFor="address">
              {paymentMethod === "paypal"
                ? "PayPal Email"
                : paymentMethod === "bank_transfer"
                ? "Bank Account Details"
                : "Wallet Address"}
            </Label>
            <Input
              id="address"
              type={paymentMethod === "paypal" ? "email" : "text"}
              placeholder={
                paymentMethod === "paypal"
                  ? "your-email@example.com"
                  : paymentMethod === "bank_transfer"
                  ? "Account number and routing details"
                  : "Cryptocurrency wallet address"
              }
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              required
            />
          </div>

          {balance < minPayout && (
            <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
              <p className="text-sm text-yellow-800">
                Minimum payout amount is ${minPayout}. You need ${(minPayout - balance).toFixed(2)} more to request a payment.
              </p>
            </div>
          )}

          <div className="flex space-x-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsOpen(false)}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={paymentMutation.isPending || balance < minPayout}
              className="flex-1 bg-success hover:bg-success/90"
            >
              {paymentMutation.isPending ? "Submitting..." : "Request Payment"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
