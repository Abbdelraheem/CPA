import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { ClipboardList, Video } from "lucide-react";
import type { Offer } from "@shared/schema";

export default function OffersSection() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: offers, isLoading } = useQuery<Offer[]>({
    queryKey: ["/api/offers"],
  });

  const startOfferMutation = useMutation({
    mutationFn: async (offerId: number) => {
      await apiRequest("POST", `/api/offers/${offerId}/start`);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Offer started! You will be redirected to complete it.",
      });
      // In a real implementation, you would redirect to the offer URL
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to start offer. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleStartOffer = (offerId: number) => {
    startOfferMutation.mutate(offerId);
  };

  return (
    <div className="space-y-8">
      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button className="bg-primary hover:bg-primary/90 py-4 flex items-center justify-center space-x-2">
              <ClipboardList className="w-5 h-5" />
              <span>Browse Offers</span>
            </Button>
            <Button className="bg-success hover:bg-success/90 py-4 flex items-center justify-center space-x-2">
              <Video className="w-5 h-5" />
              <span>Watch Ads</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Available Offers */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>High-Paying Offers</CardTitle>
          <Button variant="link" className="text-primary">
            View All
          </Button>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <Skeleton className="w-12 h-12 rounded-lg" />
                      <div className="space-y-2">
                        <Skeleton className="h-4 w-32" />
                        <Skeleton className="h-3 w-48" />
                        <div className="flex space-x-2">
                          <Skeleton className="h-5 w-20" />
                          <Skeleton className="h-5 w-24" />
                        </div>
                      </div>
                    </div>
                    <div className="text-right space-y-2">
                      <Skeleton className="h-6 w-16" />
                      <Skeleton className="h-8 w-20" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {offers?.slice(0, 3).map((offer) => (
                <div
                  key={offer.id}
                  className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <img
                        src={offer.imageUrl || "https://images.unsplash.com/photo-1553877522-43269d4ea984?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100"}
                        alt={offer.title}
                        className="w-12 h-12 rounded-lg object-cover"
                      />
                      <div>
                        <h4 className="font-medium text-gray-900">{offer.title}</h4>
                        <p className="text-sm text-gray-600">{offer.description}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge 
                            className={`text-xs ${
                              offer.difficulty === 'easy' ? 'bg-success-light text-success' :
                              offer.difficulty === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-red-100 text-red-800'
                            }`}
                          >
                            {offer.difficulty === 'easy' ? 'Quick & Easy' : 
                             offer.difficulty === 'medium' ? 'Medium' : 'Advanced'}
                          </Badge>
                          <span className="text-xs text-gray-500">
                            Network: {offer.network}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-success">${offer.payout}</div>
                      <Button
                        onClick={() => handleStartOffer(offer.id)}
                        disabled={startOfferMutation.isPending}
                        className="mt-2 bg-primary hover:bg-primary/90 text-sm"
                      >
                        {startOfferMutation.isPending ? "Starting..." : "Start Offer"}
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
