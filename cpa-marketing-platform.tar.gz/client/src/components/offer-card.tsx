import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, DollarSign, Clock, Star } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface OfferCardProps {
  offer: {
    id: number;
    title: string;
    description: string;
    payout: string;
    category: string;
    requirements: string;
    link: string;
    difficulty: "easy" | "medium" | "hard";
    estimatedTime: string;
  };
  showFullDetails?: boolean;
}

export default function OfferCard({ offer, showFullDetails = false }: OfferCardProps) {
  const { toast } = useToast();
  const [isStarting, setIsStarting] = useState(false);

  const startOfferMutation = useMutation({
    mutationFn: () => apiRequest(`/api/offers/${offer.id}/start`, "POST"),
    onSuccess: () => {
      toast({
        title: "Offer Started",
        description: "You can now complete this offer to earn money",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/user/offers"] });
      // Open offer link in new tab
      window.open(offer.link, "_blank");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to start offer",
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsStarting(false);
    },
  });

  const completeOfferMutation = useMutation({
    mutationFn: () => apiRequest(`/api/offers/${offer.id}/complete`, "POST"),
    onSuccess: () => {
      toast({
        title: "Offer Completed",
        description: `You earned $${offer.payout}!`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/user/offers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to complete offer",
        variant: "destructive",
      });
    },
  });

  const handleStartOffer = () => {
    setIsStarting(true);
    startOfferMutation.mutate();
  };

  const handleCompleteOffer = () => {
    completeOfferMutation.mutate();
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "easy":
        return "bg-green-100 text-green-800";
      case "medium":
        return "bg-yellow-100 text-yellow-800";
      case "hard":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getDifficultyStars = (difficulty: string) => {
    const count = difficulty === "easy" ? 1 : difficulty === "medium" ? 2 : 3;
    return Array.from({ length: 3 }, (_, i) => (
      <Star
        key={i}
        className={`h-3 w-3 ${
          i < count ? "text-yellow-400 fill-current" : "text-gray-300"
        }`}
      />
    ));
  };

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex justify-between items-start">
          <CardTitle className="text-lg font-semibold">{offer.title}</CardTitle>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="font-semibold">
              ${offer.payout}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-gray-600 text-sm">{offer.description}</p>
        
        <div className="flex flex-wrap gap-2">
          <Badge variant="outline" className={getDifficultyColor(offer.difficulty)}>
            <div className="flex items-center gap-1">
              {getDifficultyStars(offer.difficulty)}
              <span className="ml-1 capitalize">{offer.difficulty}</span>
            </div>
          </Badge>
          <Badge variant="outline">
            <Clock className="h-3 w-3 mr-1" />
            {offer.estimatedTime}
          </Badge>
          <Badge variant="outline">{offer.category}</Badge>
        </div>

        {showFullDetails && (
          <div className="space-y-2">
            <h4 className="font-medium text-sm">Requirements:</h4>
            <p className="text-sm text-gray-600">{offer.requirements}</p>
          </div>
        )}

        <div className="flex gap-2 pt-2">
          <Button
            onClick={handleStartOffer}
            disabled={isStarting || startOfferMutation.isPending}
            className="flex-1"
          >
            <ExternalLink className="h-4 w-4 mr-2" />
            {isStarting || startOfferMutation.isPending ? "Starting..." : "Start Offer"}
          </Button>
          <Button
            onClick={handleCompleteOffer}
            disabled={completeOfferMutation.isPending}
            variant="outline"
            className="flex-1"
          >
            <DollarSign className="h-4 w-4 mr-2" />
            {completeOfferMutation.isPending ? "Completing..." : "Mark Complete"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}