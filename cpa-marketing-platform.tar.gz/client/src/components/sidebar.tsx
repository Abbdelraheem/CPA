import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Progress } from "@/components/ui/progress";
import { Shield, Lock, Users, DollarSign, Copy } from "lucide-react";
import { useState } from "react";
import type { Activity } from "@shared/schema";

export default function Sidebar() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);

  const { data: activities, isLoading: activitiesLoading } = useQuery<Activity[]>({
    queryKey: ["/api/activities"],
  });

  const { data: referralStats } = useQuery({
    queryKey: ["/api/referrals/stats"],
  });

  const balance = parseFloat(user?.balance || "0");
  const minPayout = 50;
  const progressPercentage = Math.min((balance / minPayout) * 100, 100);
  const canRequestPayout = balance >= minPayout;

  const handleCopyReferralLink = () => {
    if (user?.referralCode) {
      const referralLink = `${window.location.origin}/ref/${user.referralCode}`;
      navigator.clipboard.writeText(referralLink);
      toast({
        title: "Copied!",
        description: "Referral link copied to clipboard",
      });
    }
  };

  const handleRequestPayment = () => {
    setPaymentModalOpen(true);
    // Trigger the payment modal (we'll need to pass this state up to the parent)
    const event = new CustomEvent('openPaymentModal');
    window.dispatchEvent(event);
  };

  return (
    <>
      {/* Payment Progress */}
      <Card>
        <CardHeader>
          <CardTitle>Payment Progress</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-600">Progress to ${minPayout} minimum</span>
              <span className="font-medium">${balance.toFixed(2)} / ${minPayout}.00</span>
            </div>
            <Progress value={progressPercentage} className="w-full h-2" />
            <p className={`text-sm mt-2 ${canRequestPayout ? 'text-success' : 'text-gray-500'}`}>
              {canRequestPayout ? '✓ Ready for payout!' : `$${(minPayout - balance).toFixed(2)} more needed`}
            </p>
          </div>
          <Button
            onClick={handleRequestPayment}
            disabled={!canRequestPayout}
            className="w-full bg-success hover:bg-success/90"
          >
            Request Payment
          </Button>
        </CardContent>
      </Card>

      {/* Referral Program */}
      <Card>
        <CardHeader>
          <CardTitle>Referral Program</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-success-light rounded-lg p-4">
            <h4 className="font-medium text-success mb-2">Earn 20% Commission</h4>
            <p className="text-sm text-gray-600">Get 20% of your referrals' earnings for life</p>
          </div>
          
          <div>
            <Label htmlFor="referral-link" className="text-sm font-medium text-gray-700 mb-2">
              Your Referral Link
            </Label>
            <div className="flex mt-2">
              <Input
                id="referral-link"
                value={user?.referralCode ? `${window.location.origin}/ref/${user.referralCode}` : "Loading..."}
                readOnly
                className="flex-1 text-sm"
              />
              <Button
                onClick={handleCopyReferralLink}
                disabled={!user?.referralCode}
                className="ml-2 bg-primary hover:bg-primary/90"
                size="sm"
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-gray-900">
                {referralStats?.count || 0}
              </div>
              <div className="text-sm text-gray-600">Referrals</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-success">
                ${referralStats?.earnings || "0.00"}
              </div>
              <div className="text-sm text-gray-600">Earned</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          {activitiesLoading ? (
            <div className="space-y-3">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="flex items-center space-x-3">
                  <Skeleton className="w-2 h-2 rounded-full" />
                  <div className="flex-1 space-y-1">
                    <Skeleton className="h-3 w-32" />
                    <Skeleton className="h-2 w-16" />
                  </div>
                  <Skeleton className="h-3 w-12" />
                </div>
              ))}
            </div>
          ) : activities && activities.length > 0 ? (
            <div className="space-y-3">
              {activities.slice(0, 5).map((activity) => (
                <div key={activity.id} className="flex items-center space-x-3">
                  <div className={`w-2 h-2 rounded-full ${
                    activity.type === 'offer_completed' ? 'bg-success' :
                    activity.type === 'ad_watched' ? 'bg-blue-500' :
                    activity.type === 'referral_bonus' ? 'bg-purple-500' :
                    'bg-gray-400'
                  }`} />
                  <div className="flex-1">
                    <p className="text-sm text-gray-900">{activity.description}</p>
                    <p className="text-xs text-gray-500">
                      {new Date(activity.createdAt!).toLocaleString()}
                    </p>
                  </div>
                  <div className="text-sm font-medium text-success">
                    +${activity.amount}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-6">
              <p className="text-sm text-gray-500">No activity yet</p>
              <p className="text-xs text-gray-400 mt-1">Complete offers or watch ads to see activity</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Trust Indicators */}
      <Card>
        <CardHeader>
          <CardTitle>Trust & Security</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center space-x-3">
              <Shield className="text-success w-4 h-4" />
              <span className="text-sm text-gray-600">SSL Encrypted</span>
            </div>
            <div className="flex items-center space-x-3">
              <Lock className="text-success w-4 h-4" />
              <span className="text-sm text-gray-600">Secure Payments</span>
            </div>
            <div className="flex items-center space-x-3">
              <Users className="text-success w-4 h-4" />
              <span className="text-sm text-gray-600">50K+ Active Users</span>
            </div>
            <div className="flex items-center space-x-3">
              <DollarSign className="text-success w-4 h-4" />
              <span className="text-sm text-gray-600">$2.5M+ Paid Out</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );
}
