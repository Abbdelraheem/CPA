import {
  users,
  offers,
  userOffers,
  ads,
  userAdViews,
  referrals,
  activities,
  payments,
  type User,
  type UpsertUser,
  type Offer,
  type InsertOffer,
  type UserOffer,
  type InsertUserOffer,
  type Ad,
  type InsertAd,
  type UserAdView,
  type InsertUserAdView,
  type Referral,
  type Activity,
  type InsertActivity,
  type Payment,
  type InsertPayment,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Offer operations
  getOffers(): Promise<Offer[]>;
  getOffer(id: number): Promise<Offer | undefined>;
  createOffer(offer: InsertOffer): Promise<Offer>;
  
  // User offer operations
  startOffer(userId: string, offerId: number): Promise<UserOffer>;
  completeOffer(userId: string, offerId: number): Promise<UserOffer | undefined>;
  getUserOffers(userId: string): Promise<UserOffer[]>;
  
  // Ad operations
  getAds(): Promise<Ad[]>;
  getAd(id: number): Promise<Ad | undefined>;
  
  // User ad view operations
  watchAd(userId: string, adId: number): Promise<UserAdView>;
  getUserAdViews(userId: string): Promise<UserAdView[]>;
  
  // Referral operations
  createReferral(referrerId: string, referredId: string): Promise<Referral>;
  getUserReferrals(userId: string): Promise<Referral[]>;
  getReferralStats(userId: string): Promise<{ count: number; earnings: string }>;
  
  // Activity operations
  createActivity(activity: InsertActivity): Promise<Activity>;
  getUserActivities(userId: string, limit?: number): Promise<Activity[]>;
  
  // Payment operations
  createPaymentRequest(payment: InsertPayment): Promise<Payment>;
  getUserPayments(userId: string): Promise<Payment[]>;
  
  // Statistics
  getUserStats(userId: string): Promise<{
    totalEarnings: string;
    todayEarnings: string;
    completedTasks: number;
    referralCount: number;
  }>;
  
  // Update user balance
  updateUserBalance(userId: string, amount: string): Promise<void>;
  generateReferralCode(): Promise<string>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getOffers(): Promise<Offer[]> {
    return await db.select().from(offers).where(eq(offers.isActive, true)).orderBy(desc(offers.payout));
  }

  async getOffer(id: number): Promise<Offer | undefined> {
    const [offer] = await db.select().from(offers).where(eq(offers.id, id));
    return offer;
  }

  async createOffer(offer: InsertOffer): Promise<Offer> {
    const [newOffer] = await db.insert(offers).values(offer).returning();
    return newOffer;
  }

  async startOffer(userId: string, offerId: number): Promise<UserOffer> {
    const [userOffer] = await db
      .insert(userOffers)
      .values({
        userId,
        offerId,
        status: "started",
      })
      .returning();
    return userOffer;
  }

  async completeOffer(userId: string, offerId: number): Promise<UserOffer | undefined> {
    const offer = await this.getOffer(offerId);
    if (!offer) return undefined;

    const [userOffer] = await db
      .update(userOffers)
      .set({
        status: "completed",
        earnings: offer.payout,
        completedAt: new Date(),
      })
      .where(and(eq(userOffers.userId, userId), eq(userOffers.offerId, offerId)))
      .returning();

    if (userOffer) {
      // Update user balance
      await this.updateUserBalance(userId, offer.payout);
      
      // Create activity
      await this.createActivity({
        userId,
        type: "offer_completed",
        description: `Completed ${offer.title} offer`,
        amount: offer.payout,
      });
    }

    return userOffer;
  }

  async getUserOffers(userId: string): Promise<UserOffer[]> {
    return await db.select().from(userOffers).where(eq(userOffers.userId, userId));
  }

  async getAds(): Promise<Ad[]> {
    return await db.select().from(ads).where(eq(ads.isActive, true));
  }

  async getAd(id: number): Promise<Ad | undefined> {
    const [ad] = await db.select().from(ads).where(eq(ads.id, id));
    return ad;
  }

  async watchAd(userId: string, adId: number): Promise<UserAdView> {
    const ad = await this.getAd(adId);
    if (!ad) throw new Error("Ad not found");

    const [adView] = await db
      .insert(userAdViews)
      .values({
        userId,
        adId,
        earnings: ad.payout,
        completed: true,
      })
      .returning();

    // Update user balance
    await this.updateUserBalance(userId, ad.payout);
    
    // Create activity
    await this.createActivity({
      userId,
      type: "ad_watched",
      description: `Watched ${ad.title} ad`,
      amount: ad.payout,
    });

    return adView;
  }

  async getUserAdViews(userId: string): Promise<UserAdView[]> {
    return await db.select().from(userAdViews).where(eq(userAdViews.userId, userId));
  }

  async createReferral(referrerId: string, referredId: string): Promise<Referral> {
    const [referral] = await db
      .insert(referrals)
      .values({
        referrerId,
        referredId,
      })
      .returning();
    return referral;
  }

  async getUserReferrals(userId: string): Promise<Referral[]> {
    return await db.select().from(referrals).where(eq(referrals.referrerId, userId));
  }

  async getReferralStats(userId: string): Promise<{ count: number; earnings: string }> {
    const result = await db
      .select({
        count: sql<number>`count(*)`,
        earnings: sql<string>`coalesce(sum(${referrals.commission}), 0)`,
      })
      .from(referrals)
      .where(eq(referrals.referrerId, userId));

    return {
      count: result[0]?.count || 0,
      earnings: result[0]?.earnings || "0.00",
    };
  }

  async createActivity(activity: InsertActivity): Promise<Activity> {
    const [newActivity] = await db.insert(activities).values(activity).returning();
    return newActivity;
  }

  async getUserActivities(userId: string, limit = 10): Promise<Activity[]> {
    return await db
      .select()
      .from(activities)
      .where(eq(activities.userId, userId))
      .orderBy(desc(activities.createdAt))
      .limit(limit);
  }

  async createPaymentRequest(payment: InsertPayment): Promise<Payment> {
    const [newPayment] = await db.insert(payments).values(payment).returning();
    return newPayment;
  }

  async getUserPayments(userId: string): Promise<Payment[]> {
    return await db
      .select()
      .from(payments)
      .where(eq(payments.userId, userId))
      .orderBy(desc(payments.requestedAt));
  }

  async getUserStats(userId: string): Promise<{
    totalEarnings: string;
    todayEarnings: string;
    completedTasks: number;
    referralCount: number;
  }> {
    const user = await this.getUser(userId);
    const referralStats = await this.getReferralStats(userId);
    
    // Get today's earnings
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const todayActivities = await db
      .select({
        total: sql<string>`coalesce(sum(${activities.amount}), 0)`,
      })
      .from(activities)
      .where(
        and(
          eq(activities.userId, userId),
          sql`${activities.createdAt} >= ${today}`
        )
      );

    // Get completed tasks count
    const completedTasks = await db
      .select({
        count: sql<number>`count(*)`,
      })
      .from(userOffers)
      .where(
        and(
          eq(userOffers.userId, userId),
          eq(userOffers.status, "completed")
        )
      );

    return {
      totalEarnings: user?.totalEarnings || "0.00",
      todayEarnings: todayActivities[0]?.total || "0.00",
      completedTasks: completedTasks[0]?.count || 0,
      referralCount: referralStats.count,
    };
  }

  async updateUserBalance(userId: string, amount: string): Promise<void> {
    await db
      .update(users)
      .set({
        balance: sql`${users.balance} + ${amount}`,
        totalEarnings: sql`${users.totalEarnings} + ${amount}`,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));
  }

  async generateReferralCode(): Promise<string> {
    const code = `PH${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
    
    // Check if code already exists
    const existing = await db.select().from(users).where(eq(users.referralCode, code));
    if (existing.length > 0) {
      return this.generateReferralCode(); // Try again
    }
    
    return code;
  }
}

export const storage = new DatabaseStorage();
