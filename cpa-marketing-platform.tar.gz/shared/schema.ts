import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  decimal,
  integer,
  boolean,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  balance: decimal("balance", { precision: 10, scale: 2 }).default("0.00"),
  totalEarnings: decimal("total_earnings", { precision: 10, scale: 2 }).default("0.00"),
  referralCode: varchar("referral_code").unique(),
  referredBy: varchar("referred_by"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const offers = pgTable("offers", {
  id: serial("id").primaryKey(),
  title: varchar("title").notNull(),
  description: text("description").notNull(),
  payout: decimal("payout", { precision: 10, scale: 2 }).notNull(),
  imageUrl: varchar("image_url"),
  network: varchar("network").notNull(),
  category: varchar("category"),
  isActive: boolean("is_active").default(true),
  requirements: text("requirements"),
  conversionType: varchar("conversion_type").notNull(), // 'signup', 'purchase', 'survey', etc.
  difficulty: varchar("difficulty").default("easy"), // 'easy', 'medium', 'hard'
  estimatedTime: integer("estimated_time"), // in minutes
  createdAt: timestamp("created_at").defaultNow(),
});

export const userOffers = pgTable("user_offers", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  offerId: integer("offer_id").references(() => offers.id).notNull(),
  status: varchar("status").default("started"), // 'started', 'completed', 'pending', 'rejected'
  earnings: decimal("earnings", { precision: 10, scale: 2 }).default("0.00"),
  startedAt: timestamp("started_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const ads = pgTable("ads", {
  id: serial("id").primaryKey(),
  title: varchar("title").notNull(),
  description: text("description"),
  videoUrl: varchar("video_url"),
  payout: decimal("payout", { precision: 10, scale: 2 }).notNull(),
  duration: integer("duration"), // in seconds
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const userAdViews = pgTable("user_ad_views", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  adId: integer("ad_id").references(() => ads.id).notNull(),
  earnings: decimal("earnings", { precision: 10, scale: 2 }).notNull(),
  watchedAt: timestamp("watched_at").defaultNow(),
  completed: boolean("completed").default(false),
});

export const referrals = pgTable("referrals", {
  id: serial("id").primaryKey(),
  referrerId: varchar("referrer_id").references(() => users.id).notNull(),
  referredId: varchar("referred_id").references(() => users.id).notNull(),
  commission: decimal("commission", { precision: 10, scale: 2 }).default("0.00"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  type: varchar("type").notNull(), // 'offer_completed', 'ad_watched', 'referral_bonus', 'payment_requested'
  description: text("description").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).default("0.00"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  method: varchar("method").notNull(), // 'paypal', 'bank_transfer', 'crypto'
  address: varchar("address").notNull(), // email for PayPal, account for bank, wallet for crypto
  status: varchar("status").default("pending"), // 'pending', 'processing', 'completed', 'failed'
  requestedAt: timestamp("requested_at").defaultNow(),
  processedAt: timestamp("processed_at"),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  offers: many(userOffers),
  adViews: many(userAdViews),
  referrals: many(referrals),
  activities: many(activities),
  payments: many(payments),
}));

export const offersRelations = relations(offers, ({ many }) => ({
  userOffers: many(userOffers),
}));

export const userOffersRelations = relations(userOffers, ({ one }) => ({
  user: one(users, {
    fields: [userOffers.userId],
    references: [users.id],
  }),
  offer: one(offers, {
    fields: [userOffers.offerId],
    references: [offers.id],
  }),
}));

export const adsRelations = relations(ads, ({ many }) => ({
  userAdViews: many(userAdViews),
}));

export const userAdViewsRelations = relations(userAdViews, ({ one }) => ({
  user: one(users, {
    fields: [userAdViews.userId],
    references: [users.id],
  }),
  ad: one(ads, {
    fields: [userAdViews.adId],
    references: [ads.id],
  }),
}));

export const referralsRelations = relations(referrals, ({ one }) => ({
  referrer: one(users, {
    fields: [referrals.referrerId],
    references: [users.id],
  }),
  referred: one(users, {
    fields: [referrals.referredId],
    references: [users.id],
  }),
}));

export const activitiesRelations = relations(activities, ({ one }) => ({
  user: one(users, {
    fields: [activities.userId],
    references: [users.id],
  }),
}));

export const paymentsRelations = relations(payments, ({ one }) => ({
  user: one(users, {
    fields: [payments.userId],
    references: [users.id],
  }),
}));

// Schemas
export const insertOfferSchema = createInsertSchema(offers).omit({
  id: true,
  createdAt: true,
});

export const insertUserOfferSchema = createInsertSchema(userOffers).omit({
  id: true,
  startedAt: true,
  completedAt: true,
});

export const insertAdSchema = createInsertSchema(ads).omit({
  id: true,
  createdAt: true,
});

export const insertUserAdViewSchema = createInsertSchema(userAdViews).omit({
  id: true,
  watchedAt: true,
});

export const insertActivitySchema = createInsertSchema(activities).omit({
  id: true,
  createdAt: true,
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  requestedAt: true,
  processedAt: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type Offer = typeof offers.$inferSelect;
export type InsertOffer = z.infer<typeof insertOfferSchema>;
export type UserOffer = typeof userOffers.$inferSelect;
export type InsertUserOffer = z.infer<typeof insertUserOfferSchema>;
export type Ad = typeof ads.$inferSelect;
export type InsertAd = z.infer<typeof insertAdSchema>;
export type UserAdView = typeof userAdViews.$inferSelect;
export type InsertUserAdView = z.infer<typeof insertUserAdViewSchema>;
export type Referral = typeof referrals.$inferSelect;
export type Activity = typeof activities.$inferSelect;
export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Payment = typeof payments.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
